<?php
/**
 * @author Thomas Sch�fer
 * @since 2008-06-29
 * add your google api key here
 */
class QApikeyGoogleGraph extends QVizualisationGoogleGraph 
{
	const KEY = "http://maps.google.com/maps?file=api&v=2&key=AIzaSyDEMaaLU6t3XuijBcO484BBhUoluqpnFa4";
}
